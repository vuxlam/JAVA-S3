package com.hutech.javas3d3.Repositories;

import com.hutech.javas3d3.Entities.Classroom;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClassroomRepository extends JpaRepository<Classroom, String> {
}
